/**
 * All imports basic libraries.
 */
import moment from 'moment';

const now = moment().format('MMMM Do YYYY, h:mm:ss a');

console.log(`Now is: ${now}`);